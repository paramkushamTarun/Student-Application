"""student URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.views.generic import TemplateView

from application import views

from application.views import register

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/', TemplateView.as_view(template_name="home.html")),
    path('loginshow/',TemplateView.as_view(template_name="login.html")),
    path('register/', views.showregister),
    path('tarun/', views.register1),
    path('login/', views.login),
    path('attendencelist/', TemplateView.as_view(template_name="Attendence list.html")),
    # path('Attendence list/',views.showfile),
    path('Subject Notes/', TemplateView.as_view(template_name="Student notes.html")),
    path('Alumilium/', TemplateView.as_view(template_name="Alumilium.html")),
    path('Feed back/', TemplateView.as_view(template_name="Feed back.html")),
    path('feedback_success/', views.feedback_success),
    path('First Year Subject Notes/', TemplateView.as_view(template_name="first_year_notes.html")),
    path('Second Year Subject Notes/', TemplateView.as_view(template_name="second_year_notes.html")),
    path('Third Year Subject Notes/', TemplateView.as_view(template_name="third_year_notes.html")),
    path('Photos/', views.photos),
    path('About Us/', TemplateView.as_view(template_name="A bout Us.html")),
    path('selectsubject/', views.displaynotes),
    path('selectsubject2/', views.displaynotes2),
    path('selectsubject3/', views.displaynotes3),
    path('First year Attendence /',TemplateView.as_view(template_name="first year attendence.html")),
    path('Second year Attendence/',TemplateView.as_view(template_name="second year attendence.html")),
    path('Third year Attendence/',TemplateView.as_view(template_name="third year attendence.html")),
    path('attendence1/', views.displayattendence1),
    path('attendence2/',views.displayattendence2),
    path('attendence3/',views.displayattendence3),
    path('Contact/',TemplateView.as_view(template_name="Contact.html")),
    path(' Acedamic Events/', TemplateView.as_view(template_name="Academic Events.html"))
]
