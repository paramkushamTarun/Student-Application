from django.http import HttpResponse
from django.shortcuts import render
from application.forms import Studentnotesform




def upload_file(request):
    if request.method == 'Post':
        Stuentnotes=Studentnotesform(request.POST,request.FILES)
        if Stuentnotes.ls_valid():
            handle_uploaded_file(request.FILES['File'])
            return HttpResponse("file uplaoded successfully")
        else :
            Stuentnotes=Studentnotesform()
            return render (request,"Student notes.html",{"form":Studentnotesform})

def handle_uploaded_file(f):
    with open('application/static/upload/name.txt', 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)


def showfile(request):
    fileread=open(r"F:\my\student\application\static\upload\technical.txt")
    data=""
    for x in fileread.readlines():
        data=data+x
    return HttpResponse(data )


path('Subject Notes/',views.showfile),