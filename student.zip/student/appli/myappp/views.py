from django.shortcuts import render
from myapp.functions.functions import handle_uploaded_file

from myapp.from import StudentForm

# Create your views here.
