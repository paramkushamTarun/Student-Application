from django import forms

class Studentfrom(forms.form):

    file = forms.FileField()