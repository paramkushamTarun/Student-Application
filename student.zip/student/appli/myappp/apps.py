from django.apps import AppConfig


class MyapppConfig(AppConfig):
    name = 'myappp'
