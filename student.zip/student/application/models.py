from django.db import models

class register(models.Model):
    First_Name = models.CharField(max_length=100)
    Last_Name = models.CharField(max_length=100)
    Birthday = models.DateField()
    Gender = models.CharField(max_length=10)
    Email = models.EmailField()
    Mobile = models.IntegerField()
    Password = models.CharField(max_length=10)

    Year = models.CharField(max_length=25)


