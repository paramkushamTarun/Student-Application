# from django import forms
#
# class Firstyearattendence(forms.Form):
#
#     file = forms.FileField()
