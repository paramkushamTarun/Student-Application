import os

from django.shortcuts import render

from django.views.generic import CreateView

# from application.forms import Firstyearattendenceform
from .models import register
from django.http import HttpResponse



def showindex(request):
    return render(request, "login.html")


def showregister(request):
    return render(request, "register.html")


def register1(request):
    first_name = request.POST.get("first_name")
    last_name = request.POST.get("last_name")
    b = request.POST.get("birthday")
    birthday1 = ""
    for x in b:
        if x == '/':
            birthday1 = birthday1 + '-'
        else:
            birthday1 = birthday1 + x
    year = ""
    m = ""
    d = ""
    m, d, year = birthday1.split('-')
    birthday = year + "-" + m + "-" + d

    gender = request.POST.get("gender")
    email = request.POST.get("email")
    phone = request.POST.get("phone")
    Password = request.POST.get("Password")
    subject = request.POST.get("subject")
    from .models import register
    data = register(First_Name=first_name, Last_Name=last_name, Birthday=birthday, Gender=gender, Email=email,
                    Mobile=phone, Password=Password, Year=subject)
    data.save()
    return render(request, "reg.html", {"msg": "Student Registered"})


def login(request):
    email = request.POST.get("email")
    Pa = request.POST.get("Pass")
    qs = register.objects.filter(Email=email, Password=Pa)
    if qs == " ":
        return render(request, "login.html", {"message": "invalid user name or password"})
    else:
        return render(request, "student_page.html")


def feedback_success(request):
    return render(request, "feedback_success.html", {"msg": "feed back successfully"})


# def upload_file(request):
#     if request.method == 'Post':
#         Firstyearattendence = Firstyearattendenceform(request.POST, request.FILES)
#         if Firstyearattendence.ls_valid():
#             handle_uploaded_file(request.FILES['File'])
#             return HttpResponse("file uplaoded successfully")
#         else:
#             Firstyearattendence = Firstyearattendenceform()
#             return render(request, "Attendence list.html", {"form": Firstyearattendenceform})
#
#
# def handle_uploaded_file(f):
#     with open('application/static/upload/name.txt', 'rb+') as f:
#         for chunk in f.chunks():
#             f.read(chunk)
#
# def showfile(request):
#     fileread=open(r"F:\my\student\application\static\upload\technical.txt")
#     data=""
#     for x in fileread.readlines():
#         data=data+x
#     return HttpResponse(data )


def displaynotes(request):
    subject=request.POST.get('subject')
    path=r"F:\\my\\student\\application\\static\\upload\\first year subjects\\"+subject+".html"
    data=""
    r=open(path)
    for x in r.readlines():
        data=data+x
    return HttpResponse(data)


def displaynotes2(request):
    subject=request.POST.get('subject')
    path=r"F:\\my\\student\\application\\static\\upload\\second year subjects\\"+subject+".html"
    data=""
    r=open(path)
    for x in r.readlines():
        data=data+x
    return HttpResponse(data)


def displaynotes3(request):
    subject=request.POST.get('subject')
    path=r"F:\\my\\student\\application\\static\\upload\\third year subjects\\"+subject+".html"
    data=""
    r=open(path)
    for x in r.readlines():
        data=data+x
    return HttpResponse(data)


def photos(request):
    data=os.listdir(r"F:\my\student\application\static\images\pics")
    return render(request,"photos.html",{"data":data })



def displayattendence1(request):
    subject=request.POST.get('subject')
    path=r"F:\\my\\student\\application\\static\\upload\\"+subject+".html"
    data=""
    r=open(path)
    for x in r.readlines():
        data=data+x
    return HttpResponse(data)



def displayattendence2(request):
    subject=request.POST.get('subject')
    path=r"F:\\my\\student\\application\\static\\upload\\"+subject+".html"
    data=""
    r=open(path)
    for x in r.readlines():
        data=data+x
    return HttpResponse(data)

def displayattendence3(request):
    subject=request.POST.get('subject')
    path=r"F:\\my\\student\\application\\static\\upload\\"+subject+".txt"
    data=""
    r=open(path)
    for x in r.readlines():
        data=data+x
    return HttpResponse(data)